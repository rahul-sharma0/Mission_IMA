package com.example.missionima;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.VideoView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ImageView img;
    VideoView vid;

    int num1, num2 = 0;

    char first, second;
    String post;

    // ============================
    // ADDED: Stores video position
    // ============================
    int currentPosition = 0;

    void post_generator1() {
        Random random = new Random();
        int randomInt = random.nextInt(3) + 97;

        num1 = randomInt;
    }

    void post_generator2() {
        Random random = new Random();
        int randomInt = random.nextInt(26) + 97;

        num2 = randomInt;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top,
                    systemBars.right, systemBars.bottom);
            return insets;
        });

        post_generator1();
        first = (char) num1;

        post_generator2();
        second = (char) num2;

        post = "raw/" + first + second;

        img = findViewById(R.id.main_img);
        vid = findViewById(R.id.main_vid);

        vid.setVisibility(VISIBLE);

        Log.e("eooeee", post);


        vid.setVideoPath("android.resource://" + getPackageName() + "/" + post);

        vid.start();

        vid.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {

                vid.setVisibility(GONE);

                // ============================
                // CHANGED
                // ============================
                finish();
                post=null;
            }
        });
    }

    // ==========================================
    // ADDED
    // Called automatically when screen turns off
    // ==========================================
    @Override
    protected void onPause() {
        super.onPause();

        if (vid != null && vid.isPlaying()) {
            currentPosition = vid.getCurrentPosition();
            vid.pause();
        }
    }

    // ==========================================
    // ADDED
    // Called automatically when screen turns on
    // ==========================================
    @Override
    protected void onResume() {
        super.onResume();

        if (vid != null) {
            vid.seekTo(currentPosition);
            vid.start();
        }
    }
}







































//package com.example.missionima;
//
//import static android.view.View.GONE;
//import static android.view.View.VISIBLE;
//import static java.lang.Math.random;
//
//import android.media.MediaPlayer;
//import android.net.Uri;
//import android.os.Bundle;
//import android.util.Log;
//import android.view.View;
//import android.widget.Button;
//import android.widget.ImageView;
//import android.widget.MediaController;
//import android.widget.VideoView;
//
//import androidx.activity.EdgeToEdge;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.core.graphics.Insets;
//import androidx.core.view.ViewCompat;
//import androidx.core.view.WindowInsetsCompat;
//
//import java.lang.reflect.Array;
//import java.text.Format;
//import java.util.Random;
//
//public class MainActivity extends AppCompatActivity {
//
//    ImageView img;
//
//
//    VideoView vid;
//
//    Button btn;
//
//    int num1,num2=0;
//
//
//    char first,second;
//    String post;
//
//
//    void post_generator1()
//    {
//        Random random =new Random();
//        int randomInt = random.nextInt(3)+97;
//
//        num1=randomInt;
////        randomInt= Integer.parseInt(null);
//   }
//
//    void post_generator2()
//    {
//        Random random =new Random();
//        int randomInt = random.nextInt(26)+97;
//
//        num2=randomInt;
////        randomInt= Integer.parseInt(null);
//    }
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        EdgeToEdge.enable(this);
//        setContentView(R.layout.activity_main);
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
//            return insets;
//        });
//
//
//        post_generator1();
//        first = (char)num1;
//        post_generator2();
//        second= (char)num2;
//
//        post= "raw/"+first+second;
//
//
//
//
//
//
//
//        img=findViewById(R.id.main_img);
//        vid=findViewById(R.id.main_vid);
//        vid.setVisibility(VISIBLE);
////        Format path= "android.resource://"+ getPackageName()+"/"+ R.raw+.+post.toString();
////        Uri uri = Uri.parse("android.resource://"+ getPackageName()+"/"+post);
////        String path ="android.resource://+ getPackageName()+"/"+ R.raw.post";
//
//        Log.e("eooeee",post);
//        vid.setVideoPath("android.resource://"+ getPackageName()+"/"+post);
////        MediaController md = new MediaController(this);
////        md.setAnchorView(vid);
////        vid.setMediaController(md);
//        vid.start();
//
//
//
//        vid.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
//            @Override
//            public void onCompletion(MediaPlayer mediaPlayer) {
//                vid.setVisibility(GONE);
//                System.exit(0);
//            }
//        });
//
//
//
//
//
//
////        md.onFinishInflate();
//
//
////        num=Integer.parseInt(String.valueOf(Math.random()));
////
////        System.out.println(num);
//
////        btn= findViewById(R.id.btn_check);
////
////        btn.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View view) {
////
//////
//////                Random random =new Random();
//////                int randomInt = random.nextInt(72);
//////
//////                if (randomInt==60)
//////                {
//////                    String name = "az";
//////                }
////
////
////
////
////
////                Log.e("eooeee",post);
////
////
////
//////                while (num>0 && num>=70){
//////                }
////
////            }
////        });
//
//
//
//    }
//}