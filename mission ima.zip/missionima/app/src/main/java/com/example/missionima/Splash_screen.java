package com.example.missionima;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class Splash_screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_splash_screen);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView txt = findViewById(R.id.txt_quote);
        Random random = new Random();

        String[] quotes = {
                "एक कदम और! बस यही फर्क बनाता है सैनिक और आम आदमी में!",
                "जब दिमाग ‘बस’ बोले—तभी असली ट्रेनिंग शुरू होती है!",
                "यहाँ बहाने नहीं चलते—या तो करेगा, या बाहर जाएगा।",
                "शरीर टूटे तो टूटने दे—हौसला नहीं टूटना चाहिए",
                "सैनिक बनने आए हो—तो आराम का नाम भूल जाओ",
                "गिरा? उठ! फिर गिरा? फिर उठ! रुकना मना है",
                "हर दिन जंग है—या जीत, या सीख।",
                "कमज़ोर सोच नहीं, ताकतवर इरादा चाहिए।",
                "आज हार मान ली, तो जिंदगी भर पछताएगा।",
                "वर्दी चाहिए तो नींद की कुर्बानी दे।",
                "एक कदम और! बस यही फर्क बनाता है सैनिक और आम आदमी में!",
                "जब दिमाग ‘बस’ बोले—तभी असली ट्रेनिंग शुरू होती है!",
                "Your Uniform is waiting for you with your Name & Stars on it!!",
                "You are the reason for the happiness & sorrow of your parents \nYou should make them Proud and Happy",
                "Balidan \n Parmo\nDharma",
                "Born to Lead\nTrained to Fight\nDestined to Win",
                "When your body says stop, your mind must say one more step",
                "A soldier is not born, he is forged in hardship, routine, and sacrifice",
                "From Commander to Cadet \nthe journey begins with Discipline",
                "Don't do anything for what makes you regret later",
                "This is your last chance and you have to\n work hard",
                "Remember when u were at your PRIME \njust work hard keep \nupgrade yourself,life and everything"
        };

        int index = random.nextInt(quotes.length);
        txt.setText(quotes[index]);



        Intent intent =new Intent(Splash_screen.this,MainActivity.class);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(intent);
              finish();
            }
        },5000);



    }
}